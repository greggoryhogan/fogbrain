</main>
<footer>
    <?php bhfe_wp_nav_menu('footer-menu'); ?>    
</footer>
<img src="<?php echo THEME_URI; ?>/img/question.png" class="fog fog-question" loading="lazy" width="1920" height="1920" />
<img src="<?php echo THEME_URI; ?>/img/answer.png" class="fog fog-answer" loading="lazy" width="1920" height="1920" />
<?php wp_footer(); ?>
</body>
</html>